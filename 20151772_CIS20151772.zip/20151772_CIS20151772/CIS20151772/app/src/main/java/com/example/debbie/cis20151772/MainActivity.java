package com.example.debbie.cis20151772;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends Activity {

    public void Open_Directory (View view) {

        Intent directory = new Intent(this, Directory.class );

        startActivity(directory);
    }

    public void Open_Events (View view) {

        Intent event = new Intent(Intent.ACTION_VIEW, Uri.parse("http://cis.ncu.edu.jm/#events") );

        startActivity(event);
    }

    public void Open_Courses (View view) {

        Intent courses = new Intent(this, Courses.class);

        startActivity(courses);
    }

    public void Open_Schedule (View view)
    {
        Intent schedule = new Intent(this, Schedule.class);
        startActivity(schedule);
    }

    public void Open_News (View view)
    {
        Intent news = new Intent(this, News.class);
        startActivity(news);
    }

    public void Open_Admissions (View view)
    {
        Intent admissions = new Intent(this, Admissons.class);
        startActivity(admissions);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
