package com.example.debbie.cis20151772;

import android.os.Bundle;
import android.app.Activity;
import android.webkit.WebView;

public class News extends Activity {

    private WebView wv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);
        wv = new WebView(this);
        wv.loadUrl("cis.ncu.edu.jm/#news");

    }

}
