package com.example.debbie.cis20151772;

import android.os.Bundle;
import android.app.Activity;
import android.webkit.WebView;

public class Schedule extends Activity {

    private WebView wv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);

        wv = new WebView(this);
        wv.loadUrl("https://cis.ncu.edu.jm/schedule.aspx");
    }

}
